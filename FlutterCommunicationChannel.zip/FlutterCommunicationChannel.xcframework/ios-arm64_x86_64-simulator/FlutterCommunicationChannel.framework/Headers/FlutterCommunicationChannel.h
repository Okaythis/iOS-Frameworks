//
//  FlutterCommunicationChannel.h
//  FlutterCommunicationChannel
//
//  Created by Ben Ogie on 27/08/2020.
//  Copyright © 2020 Ben Ogie. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FlutterCommunicationChannel.
FOUNDATION_EXPORT double FlutterCommunicationChannelVersionNumber;

//! Project version string for FlutterCommunicationChannel.
FOUNDATION_EXPORT const unsigned char FlutterCommunicationChannelVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FlutterCommunicationChannel/PublicHeader.h>


